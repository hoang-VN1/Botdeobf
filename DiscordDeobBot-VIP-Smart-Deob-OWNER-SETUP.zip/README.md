# Luraph Deobfuscator Discord Bot

This build contains only the Luraph deobfuscation engines: **v14.7, v14.8, v14.9, v15, and v15.1**.

## Commands

- `/deob` — upload a Lua/Luau file, paste source, or provide a loader URL. Choose public Luraph v14.7, v14.8, v14.9, or v15.
- `/vipdeob` — run Luraph v15.1. Requires the VIP role configured for that server.
- `/detect` — identify a supported Luraph version where possible.
- `/get` — fetch source from a public HTTP/HTTPS URL.
- `/supported` — list supported engines.
- `/help` — show command details.

### OWNER-only setup commands

Only Discord user ID `1390532560794292315` can run these commands:

- `/setup_server server_id:<ID>` — activate the server where the command is run. The supplied ID must match that server.
- `/setup_channel server_id:<ID> channel_id:<ID>` — select the one text channel where members can use bot commands. Run this in that server after activation.
- `/setup_vip_role server_id:<ID> role_id:<ID>` — configure the VIP role for that server.
- `/setup_remove_server server_id:<ID>` — disable the bot and delete that server's settings.

A server is usable by members only after it is activated and a channel is configured. All settings are saved in `bot_config.json` beside `bot.py` and survive restarts. Keep this file when moving/restarting the bot. Each server has its own channel and VIP role. The OWNER can run commands anywhere; other users are restricted to the activated server's configured channel. Threads under that channel are also allowed.

## Windows setup

1. Install Python 3.10 or newer.
2. Run `setup.bat` once.
3. Put your Discord bot token in `.env` after `DISCORD_TOKEN=`.
5. Run `start.bat`.

## Linux host setup

Upload this ZIP and extract it at the host's main server folder. In the host startup settings, set the Python/app file to `host_start.py` and the requirements file to `requirements.txt`. Set `DISCORD_TOKEN` in the host's environment variables. No Presence Intent or Server Members Intent is required for the setup/access-control system.

`host_start.py` tries to build Linux Luau executables if missing. This requires `git`, CMake, `g++`, Python, and GitHub network access. The bot needs `bin/luau` and `bin/luau-ast` on Linux; Windows `.exe` files cannot run there. If the host cannot build them, the provider must supply those Linux tools. Startup logs report clearly if they are missing.

## Limits

- Input limit: 25 MiB by default. Set `MAX_SOURCE_MB` in the host environment to a value from 1 to 100 if you need a different limit; the hoster's own upload cap still applies.
- Engine time limit: 14 minutes. Larger jobs need more CPU/RAM, and a host that kills long-running processes may stop them sooner.
- The engine may use up to 48 trace runs and 2,000 devirtualization rounds, stopping early when it reaches a fixed point.
- Runtime errors such as `script error` are reported with a **Deobfuscation Failed.** embed instead of being presented as successful output.
- Luraph v14 engines are selected with the version buttons. v15 uses the included v15 engine; v15.1 is VIP-only through `/vipdeob`.
- A loader URL may need authentication or game/runtime state; plain HTTP fetching cannot supply that context.

Only use this bot on code you are authorized to inspect. Keep `.env` and your bot token private.

