"""Host entry point: build missing Linux Luau tools, then start the Discord bot."""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent
BOT = ROOT / "bot.py"


def main() -> None:
    if sys.platform.startswith("linux"):
        required_tools = (ROOT / "bin" / "luau", ROOT / "bin" / "luau-ast")
        if not all(path.is_file() and os.access(path, os.X_OK) for path in required_tools):
            setup = ROOT / "setup_luau_linux.sh"
            if not setup.is_file():
                raise SystemExit("setup_luau_linux.sh is missing; cannot build the required Linux Luau tools.")
            print("Linux Luau tools are missing; attempting the one-time setup...", flush=True)
            result = subprocess.run(["sh", str(setup)], cwd=ROOT, check=False)
            if result.returncode != 0:
                raise SystemExit(
                    "Luau setup failed (see the build error above). The host needs git, CMake, g++, "
                    "GitHub access, and enough memory/disk to compile Luau. Do not start bot.py "
                    "until bin/luau and bin/luau-ast exist and are executable."
                )
            missing = [str(path.relative_to(ROOT)) for path in required_tools
                       if not path.is_file() or not os.access(path, os.X_OK)]
            if missing:
                raise SystemExit("Luau setup returned success but these executables are missing: " + ", ".join(missing))

    if not BOT.is_file():
        raise SystemExit(f"bot.py was not found beside this launcher: {BOT}")
    os.execv(sys.executable, [sys.executable, str(BOT)])


if __name__ == "__main__":
    main()
