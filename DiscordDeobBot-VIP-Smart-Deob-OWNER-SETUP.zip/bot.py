"""Discord bot for deobfuscating and inspecting Lua sources."""
from __future__ import annotations

import asyncio
import http.client
import ipaddress
import io
import logging
import json
import os
import re
import socket
import ssl
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path, PurePosixPath

import discord
from dotenv import load_dotenv
from discord.ext import commands

load_dotenv(dotenv_path=Path(__file__).resolve().parent / ".env")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")

MAX_SOURCE_MB = int(os.environ.get("MAX_SOURCE_MB", "25"))
if not 1 <= MAX_SOURCE_MB <= 100:
    raise ValueError("MAX_SOURCE_MB must be between 1 and 100.")
MAX_SOURCE_BYTES = MAX_SOURCE_MB * 1024 * 1024
MAX_RESULT_BYTES = 20_000_000
# Leave a little margin under Discord's interaction-token lifetime so the bot
# can still post the result after a long-running job.
TIMEOUT_SECONDS = 840
OWNER_ID = 1390532560794292315
CONFIG_PATH = Path(__file__).resolve().parent / "bot_config.json"
DEFAULT_CONFIG = {"guilds": {}}


def load_config() -> dict:
    try:
        data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        if not isinstance(data, dict) or not isinstance(data.get("guilds", {}), dict):
            raise ValueError("Invalid bot_config.json structure")
        data.setdefault("guilds", {})
        return data
    except FileNotFoundError:
        return {"guilds": {}}
    except Exception as exc:
        logging.exception("Could not read bot_config.json; using an empty configuration: %s", exc)
        return {"guilds": {}}


def save_config() -> None:
    temporary = CONFIG_PATH.with_suffix(".json.tmp")
    temporary.write_text(json.dumps(config, indent=2, ensure_ascii=False), encoding="utf-8")
    temporary.replace(CONFIG_PATH)


config = load_config()

EMBED_COLOR = discord.Color.from_rgb(0, 0, 0)
VERSION_RE = re.compile(r"protected using Luraph Obfuscator v(14\.(?:7|8|9)|15(?:\.\d+)?)\b", re.I)


def get_engine_command(version: str) -> list[str]:
    if version not in {"14.7", "14.8", "14.9", "15", "15.1"}:
        raise ValueError("Only Luraph 14.7, 14.8, 14.9, 15, and 15.1 are supported.")
    bot_root = Path(__file__).resolve().parent
    configured_root = os.environ.get("DEOB_ENGINE_DIR", "").strip()
    candidates = []
    if configured_root:
        configured_path = Path(configured_root).expanduser()
        candidates.append(configured_path if configured_path.is_absolute() else bot_root / configured_path)
    # Common layouts: bot.py beside deobf/, engine files beside bot.py, or a
    # host panel extracting deobf-folder.zip into an extra wrapper directory.
    candidates.extend((bot_root / "deobf", bot_root))

    def is_engine_root(candidate: Path) -> bool:
        has_obfuscators = (
            (candidate / "obfuscators").is_dir()
            or (candidate / "obfuscators-folder.zip").is_file()
        )
        return (
            (candidate / "cli.py").is_file()
            and (candidate / "deob.py").is_file()
            and has_obfuscators
        )

    engine_root = next((path for path in candidates if is_engine_root(path)), None)
    if engine_root is None:
        # Search below the bot directory so common host layouts such as
        # /home/container/deobf-folder/deobf are found automatically.
        ignored_dirs = {".git", ".venv", "venv", "node_modules", "__pycache__", ".cache"}
        discovered = []
        for current, directories, _files in os.walk(bot_root):
            directories[:] = [name for name in directories if name not in ignored_dirs]
            candidate = Path(current)
            if is_engine_root(candidate):
                discovered.append(candidate)
        if discovered:
            engine_root = min(discovered, key=lambda path: len(path.parts))

    if engine_root is None:
        raise RuntimeError(
            "Luraph engine files were not found. Extract the engine ZIP somewhere inside the bot folder. "
            f"The engine files need cli.py, deob.py, and either obfuscators/ or obfuscators-folder.zip. Bot folder: {bot_root}. "
            "If you set DEOB_ENGINE_DIR, point it to the folder containing those three items."
        )

    # Explain the common host mismatch before subprocess reports a traceback.
    bin_dir = engine_root / "bin"
    if os.name == "nt":
        missing_tools = [name for name in ("luau.exe", "luau-ast.exe")
                         if not (bin_dir / name).is_file()]
    else:
        missing_tools = [name for name in ("luau", "luau-ast")
                         if not (bin_dir / name).is_file() or not os.access(bin_dir / name, os.X_OK)]
    if missing_tools:
        missing = ", ".join(f"bin/{name}" for name in missing_tools)
        if os.name == "nt":
            raise RuntimeError(f"Luraph runtime tools are missing: {missing}.")
        raise RuntimeError(
            f"Luraph Linux runtime tools are missing: {missing}. Run host_start.py so it can build them; "
            "the host needs git, CMake, g++, and GitHub network access."
        )

    # Hosts that only accept file uploads commonly have the plugin package as
    # obfuscators-folder.zip instead of an extracted obfuscators/ directory.
    # The v15 runner imports the package immediately, so expand it safely
    # before starting either runner.
    package_dir = engine_root / "obfuscators"
    package_zip = engine_root / "obfuscators-folder.zip"
    required_plugins = (
        package_dir / "luraph_v14_7" / "__init__.py",
        package_dir / "luraph_v14_8" / "__init__.py",
        package_dir / "luraph_v14_9" / "__init__.py",
        package_dir / "luraph_v15" / "__init__.py",
    )
    if not all(path.is_file() for path in required_plugins):
        if not package_zip.is_file():
            raise RuntimeError(
                f"The Luraph plugin package is incomplete in {engine_root}. "
                "Upload obfuscators-folder.zip beside bot.py and deob.py."
            )
        root_resolved = engine_root.resolve()
        try:
            with zipfile.ZipFile(package_zip) as archive:
                for member in archive.infolist():
                    member_path = PurePosixPath(member.filename)
                    if member_path.is_absolute() or ".." in member_path.parts:
                        raise RuntimeError(f"Unsafe path in {package_zip.name}: {member.filename}")
                    target = (engine_root / Path(*member_path.parts)).resolve()
                    if target != root_resolved and root_resolved not in target.parents:
                        raise RuntimeError(f"Unsafe path in {package_zip.name}: {member.filename}")
                archive.extractall(engine_root)
        except (OSError, zipfile.BadZipFile) as exc:
            raise RuntimeError(f"Could not extract {package_zip.name}: {exc}") from exc
        if not all(path.is_file() for path in required_plugins):
            raise RuntimeError(
                f"{package_zip.name} was extracted, but the Luraph plugin folders are missing. "
                "The ZIP should contain obfuscators/luraph_v14_7, luraph_v14_8, luraph_v14_9, and luraph_v15."
            )

    if version.startswith("15"):
        script = engine_root / "deob.py"
        engine_args = ["--obfuscator", "luraph_v15", "--timeout", str(TIMEOUT_SECONDS),
                       "--budget", "600", "--max-runs", "48", "--devirt-rounds", "2000"]
    else:
        script = engine_root / "cli.py"
        engine_args = ["--engine", version, "--timeout", str(TIMEOUT_SECONDS), "--budget", "600",
                       "--max-runs", "48", "--devirt-rounds", "2000", "--trace-fallback"]
    return [sys.executable, str(script), "{input}", "-o", "{output}", *engine_args]


def loadstring_url(text: str) -> str | None:
    match = re.search(r"https?://[^\s\"']+", text, re.I)
    if not match:
        return None
    url = match.group(0).rstrip(" )],;`>")
    if not is_allowed_fetch_url(url):
        raise ValueError("Only public HTTP or HTTPS URLs can be fetched.")
    return url


def is_allowed_fetch_url(url: str) -> bool:
    try:
        parts = urllib.parse.urlsplit(url)
        if parts.scheme.lower() not in ("http", "https") or not parts.hostname:
            return False
        if parts.username is not None or parts.password is not None:
            return False
        port = parts.port
    except ValueError:
        return False
    if port is not None and port not in (80, 443):
        return False
    return True


def resolve_public_host(host: str, port: int) -> tuple[str, str]:
    ascii_host = host.encode("idna").decode("ascii")
    try:
        literal_ip = ipaddress.ip_address(ascii_host.strip("[]"))
        resolved = [(literal_ip.compressed, socket.AF_INET6 if literal_ip.version == 6 else socket.AF_INET)]
    except ValueError:
        try:
            records = socket.getaddrinfo(ascii_host, port, type=socket.SOCK_STREAM)
        except OSError as exc:
            raise ValueError(f"Could not resolve URL host: {exc}") from exc
        resolved = list({(record[4][0].split("%")[0], record[0]) for record in records})
    if not resolved:
        raise ValueError("The URL host did not resolve to an address.")
    for address, _family in resolved:
        if not ipaddress.ip_address(address).is_global:
            raise ValueError("Only publicly reachable HTTP/HTTPS URLs can be fetched.")
    return ascii_host, resolved[0][0]


def fetch_url(url: str) -> str:
    current = url
    for redirect_count in range(6):
        if not is_allowed_fetch_url(current):
            raise ValueError("Enter a valid public HTTP or HTTPS URL using port 80 or 443.")
        parts = urllib.parse.urlsplit(current)
        host = parts.hostname or ""
        port = parts.port or (443 if parts.scheme.lower() == "https" else 80)
        ascii_host, pinned_ip = resolve_public_host(host, port)
        target = urllib.parse.urlunsplit(("", "", parts.path or "/", parts.query, ""))

        class PinnedHTTPConnection(http.client.HTTPConnection):
            def connect(self):
                self.sock = socket.create_connection((pinned_ip, self.port), self.timeout)

        class PinnedHTTPSConnection(http.client.HTTPSConnection):
            def connect(self):
                sock = socket.create_connection((pinned_ip, self.port), self.timeout)
                self.sock = self._context.wrap_socket(sock, server_hostname=ascii_host)

        try:
            connection_type = PinnedHTTPSConnection if parts.scheme.lower() == "https" else PinnedHTTPConnection
            connection = connection_type(ascii_host, port=port, timeout=15)
            connection.request("GET", target, headers={
                "User-Agent": "LuaDeobBot/1.0",
                "Accept": "text/plain, application/octet-stream, */*",
                "Accept-Encoding": "identity",
            })
            response = connection.getresponse()
            if response.status in (301, 302, 303, 307, 308):
                location = response.getheader("Location")
                connection.close()
                if not location or redirect_count == 5:
                    raise ValueError("The URL redirected too many times or omitted its redirect target.")
                current = urllib.parse.urljoin(current, location)
                continue
            if response.status < 200 or response.status >= 300:
                raise ValueError(f"The URL returned HTTP {response.status}.")
            data = response.read(MAX_SOURCE_BYTES + 1)
            charset = response.headers.get_content_charset() or "utf-8"
            connection.close()
        except (OSError, http.client.HTTPException, ssl.SSLError) as exc:
            raise ValueError(f"Could not retrieve the source URL: {exc}") from exc
        if len(data) > MAX_SOURCE_BYTES:
            raise ValueError(f"The downloaded source exceeds the {MAX_SOURCE_MB} MB limit.")
        return data.decode(charset, errors="replace")
    raise ValueError("The URL redirected too many times.")


def fetch_loader(url: str) -> str:
    return fetch_url(url)


def summarize_engine_error(detail: str, limit: int = 1200) -> str:
    """Keep the exception headline as well as the most useful traceback tail."""
    detail = detail.strip() or "Engine exited with an error."
    if len(detail) <= limit:
        return detail
    lines = detail.splitlines()
    headline = lines[0]
    tail = "\n".join(lines[-12:])
    if len(headline) + len(tail) + 24 <= limit:
        return f"{headline}\n… traceback tail …\n{tail}"
    return detail[:limit]


def read_log_tail(path: Path, limit: int = 64_000) -> str:
    """Read only the end of an engine log so large jobs don't fill bot RAM."""
    with path.open("rb") as stream:
        stream.seek(0, os.SEEK_END)
        size = stream.tell()
        stream.seek(max(0, size - limit), os.SEEK_SET)
        return stream.read().decode("utf-8", errors="replace")


def run_engine(source: str, version: str) -> tuple[str, str]:
    encoded = source.encode("utf-8")
    if len(encoded) > MAX_SOURCE_BYTES:
        raise ValueError(f"Input exceeds the {MAX_SOURCE_MB} MB limit.")
    command = get_engine_command(version)
    with tempfile.TemporaryDirectory(prefix="deob-") as folder:
        root = Path(folder)
        input_path, output_path = root / "input.lua", root / "output.lua"
        input_path.write_bytes(encoded)
        expanded = [part.replace("{input}", str(input_path)).replace("{output}", str(output_path))
                    .replace("{version}", version)
                    for part in command]
        if not any("{input}" in part for part in command) or not any("{output}" in part for part in command):
            raise RuntimeError("DEOB_COMMAND must include both {input} and {output} placeholders.")
        stdout_path, stderr_path = root / "engine.stdout.log", root / "engine.stderr.log"
        try:
            with stdout_path.open("wb") as stdout_log, stderr_path.open("wb") as stderr_log:
                completed = subprocess.run(
                    expanded, stdout=stdout_log, stderr=stderr_log,
                    timeout=TIMEOUT_SECONDS, cwd=folder, check=False,
                )
        except subprocess.TimeoutExpired as exc:
            raise RuntimeError("The deobfuscator exceeded the 14 minute limit. Large inputs need more host CPU/RAM.") from exc
        except OSError as exc:
            raise RuntimeError(f"Could not start the Luraph engine: {exc}") from exc
        if completed.returncode != 0:
            detail = (read_log_tail(stderr_path) or read_log_tail(stdout_path)
                      or "Engine exited with an error.").strip()
            raise RuntimeError(summarize_engine_error(detail))
        if not output_path.is_file():
            raise RuntimeError("The engine finished without creating the output file.")
        result = output_path.read_bytes()
        if len(result) > MAX_RESULT_BYTES:
            raise RuntimeError("Deobfuscated output exceeds Discord's upload limit.")
        engine_log = (read_log_tail(stdout_path) + "\n" + read_log_tail(stderr_path))[-64_000:]
        decoded = result.decode("utf-8", errors="replace")
        normalized = decoded.strip()
        if normalized.startswith("-- Deobfuscated in ") and not normalized.partition("\n")[2].strip():
            raise RuntimeError(
                "The engine produced no deobfuscated code (only its credit banner). "
                "It could not recover this input; check the engine log and host memory limit."
            )
        return decoded, engine_log


def is_owner(user: discord.abc.User) -> bool:
    return user.id == OWNER_ID


def guild_config(guild_id: int) -> dict:
    return config.get("guilds", {}).get(str(guild_id), {})


async def require_command_access(interaction: discord.Interaction) -> bool:
    if is_owner(interaction.user):
        return True
    if interaction.guild is None:
        await interaction.response.send_message("Bot commands can only be used inside a registered server.", ephemeral=True)
        return False
    settings = guild_config(interaction.guild.id)
    if not settings.get("enabled"):
        await interaction.response.send_message("This server has not been activated by the bot owner.", ephemeral=True)
        return False
    channel_id = settings.get("channel_id")
    current_channel = getattr(interaction.channel, "id", None)
    parent_id = getattr(interaction.channel, "parent_id", None)
    if not channel_id:
        await interaction.response.send_message("The owner has activated this server but has not configured its bot channel yet.", ephemeral=True)
        return False
    if current_channel != channel_id and parent_id != channel_id:
        await interaction.response.send_message(f"Use bot commands in the configured channel <#{channel_id}>.", ephemeral=True)
        return False
    return True


async def require_owner(interaction: discord.Interaction) -> bool:
    if not is_owner(interaction.user):
        await interaction.response.send_message("Only the bot owner can use setup commands.", ephemeral=True)
        return False
    if interaction.guild is None:
        await interaction.response.send_message("Run this setup command inside the target Discord server.", ephemeral=True)
        return False
    return True


async def read_input(file: discord.Attachment | None, text: str | None,
                     *, allow_plain_text: bool, fetch_urls: bool = True) -> str:
    if file:
        if file.size > MAX_SOURCE_BYTES:
            raise ValueError(f"Uploaded file exceeds the {MAX_SOURCE_MB} MB limit.")
        data = await file.read()
        if len(data) > MAX_SOURCE_BYTES:
            raise ValueError(f"Uploaded file exceeds the {MAX_SOURCE_MB} MB limit.")
        return data.decode("utf-8", errors="replace")
    if text is None:
        raise ValueError("Provide a file or source text.")
    if fetch_urls:
        url = loadstring_url(text)
        if url:
            return await asyncio.to_thread(fetch_loader, url)
    if allow_plain_text:
        if len(text.encode("utf-8")) > MAX_SOURCE_BYTES:
            raise ValueError(f"Input exceeds the {MAX_SOURCE_MB} MB limit.")
        return text
    if "loadstring" in text.lower() and ("luarmor" in text.lower() or "https://" in text.lower()):
        raise ValueError("I couldn't find a supported HTTPS URL in that loadstring.")
    raise ValueError("Paste a loadstring containing its HTTP or HTTPS loader URL.")


def detect_obfuscator(source: str) -> tuple[str, float, str]:
    banner = VERSION_RE.search(source[:4096])
    if banner:
        version = banner.group(1)
        return f"Luraph v{version}", 0.9999, "Direct"
    header = re.search(r"protected using Luraph Obfuscator v(14)\b", source[:4096], re.I)
    if header:
        return "Luraph v14 (minor version not identified)", 0.99, "Direct"
    head = source.lstrip()[:4000]
    if head.startswith("local init = (function(...") and "return({" in source[:20000]:
        return "Likely Luraph v14.8 or v14.9 (minor version ambiguous)", 0.93, "Direct"
    if head.startswith("return({") and "bit32" in source[:100000]:
        return "Likely Luraph v14.x (minor version ambiguous)", 0.88, "Direct"
    return "Unknown obfuscator", 0.0, "Direct"


def support_status(label: str) -> str:
    normalized = label.casefold()
    if normalized.startswith("luraph v14.7") or normalized.startswith("luraph v14.8") or normalized.startswith("luraph v14.9"):
        return "Supported by this bot."
    if normalized.startswith("luraph v15.1"):
        return "VIP-only; use /vipdeob."
    if normalized.startswith("luraph v15"):
        return "Supported by this bot."
    if "luraph v14" in normalized and "ambiguous" in normalized:
        return "Supported; choose the matching v14 version in /deob."
    if normalized.startswith("unknown"):
        return "No matching obfuscator was identified."
    return "Detected, but no bundled deobfuscator is available."


def source_preview(source: str, limit: int = 780) -> str:
    lines = source.splitlines()
    preview = "\n".join(lines[:5]) or "(empty source)"
    preview = preview.replace("```", "''' ")
    if len(preview) > limit:
        preview = preview[:limit - 3] + "..."
    remaining = max(0, len(lines) - 5)
    if remaining:
        preview += f"\n... and {remaining} more!"
    return preview


def make_detect_embed(source: str) -> discord.Embed:
    label, confidence, profile = detect_obfuscator(source)
    embed = discord.Embed(
        title="🟢 Detection complete",
        description=(f"Luraph Deobfuscator thinks this file is **{label}**.\n"
                    f"**Profile:** {profile}\n"
                    f"**Confidence:** {confidence * 100:.2f}%\n\n"
                    f"**Status:** {support_status(label)}"),
        color=EMBED_COLOR,
    )
    embed.set_author(name="Luraph Deobfuscator")
    return embed


def make_get_embed(source: str, url: str, elapsed: float) -> discord.Embed:
    hostname = urllib.parse.urlsplit(url).hostname or "URL"
    label, confidence, _profile = detect_obfuscator(source)
    embed = discord.Embed(
        title="✅ Script fetched",
        description=f"Downloaded from **{discord.utils.escape_markdown(hostname)}**.",
        color=EMBED_COLOR,
        timestamp=discord.utils.utcnow(),
    )
    embed.set_author(name="Luraph Deobfuscator")
    embed.add_field(name="Preview · first 5 lines", value=f"```lua\n{source_preview(source)}\n```", inline=False)
    embed.add_field(name="Detection complete", value=(
        f"Luraph Deobfuscator thinks this file is **{label}**.\n"
        f"**Confidence:** {confidence * 100:.2f}%\n"
        f"**Status:** {support_status(label)}"
    ), inline=False)
    size = len(source.encode("utf-8"))
    embed.set_footer(text=f"Fetched in {elapsed:.2f}s · {size / 1024:.2f} KB")
    return embed


def make_result_embed(title: str, description: str, source: str,
                      elapsed: float | None = None,
                      filename: str = "deobfuscated.lua",
                      language: str = "lua") -> discord.Embed:
    embed = discord.Embed(
        title=f"✅ {title}", description=description,
        color=EMBED_COLOR, timestamp=discord.utils.utcnow(),
    )
    embed.set_author(name="Luraph Deobfuscator")
    preview = "\n".join(source.splitlines()[:5]) or "(empty output)"
    preview = preview.replace("```", "''' ")
    if len(preview) > 850:
        preview = preview[:847] + "..."
    embed.add_field(name="Preview · first 5 lines", value=f"```{language}\n{preview}\n```", inline=False)
    embed.add_field(name="Output file", value=f"`{filename}` is attached below.", inline=False)
    if elapsed is not None:
        embed.set_footer(text=f"Completed in {elapsed:.2f}s")
    else:
        embed.set_footer(text="Source attached below")
    return embed


def make_failure_embed(details: str | None = None) -> discord.Embed:
    embed = discord.Embed(
        title="Deobfuscation Failed.",
        description="The bot could not recover usable Lua code from this input.",
        color=discord.Color.red(),
        timestamp=discord.utils.utcnow(),
    )
    if details:
        safe_details = details.replace("```", "''' ")[:900]
        embed.add_field(name="Details", value=f"```text\n{safe_details}\n```", inline=False)
    embed.set_author(name="Luraph Deobfuscator")
    return embed


def find_deobfuscation_failure(result: str, engine_log: str) -> str | None:
    if "-- yeah this ran at runtime and its gonna be shit" in result.casefold():
        return "The engine produced only a behavior trace, not recovered Lua source."
    if "unresolved luraph runtime helper" in result.casefold():
        return "The result still contains unresolved Luraph runtime helpers."
    if "returning behaviour trace because --trace-fallback was requested" in engine_log.casefold():
        return "The engine could produce only a behavior trace, not recovered Lua source."
    markers = (
        re.compile(r"(?im)^--\s*run status:\s*(script error|timed out|stopped in an endless loop)\s*:?[ \t]*(.*)$"),
        re.compile(r"(?im)^\[\*\]\s*(script error|timed out|stopped in an endless loop)\s*:?[ \t]*(.*)$"),
    )
    for pattern in markers:
        match = pattern.search(result) or pattern.search(engine_log)
        if match:
            reason = " ".join(part for part in match.groups() if part).strip()
            return reason[:850] or "The script failed while running in the deobfuscator's sandbox."
    return None


PUBLIC_ENGINE_OPTIONS = [
    ("14.7", "Luraph 14.7"),
    ("14.8", "Luraph 14.8"),
    ("14.9", "Luraph 14.9"),
    ("15", "Luraph 15"),
]
VIP_ENGINE_OPTIONS = [("15.1", "Luraph 15.1")]


def member_has_vip_role(user: discord.abc.User, guild_id: int | None = None) -> bool:
    if is_owner(user):
        return True
    if not isinstance(user, discord.Member):
        return False
    target_guild_id = guild_id or user.guild.id
    role_id = guild_config(target_guild_id).get("vip_role_id")
    return bool(role_id and any(role.id == role_id for role in user.roles))


def recommended_engine(label: str) -> str | None:
    normalized = label.casefold()
    luraph = re.match(r"luraph v(14\.7|14\.8|14\.9|15\.1|15)(?:\b|$)", normalized)
    if luraph:
        return luraph.group(1)
    return None


async def run_selected_deob(interaction: discord.Interaction, source: str, engine: str) -> None:
    start = time.monotonic()
    try:
        allowed = {name for name, _label in PUBLIC_ENGINE_OPTIONS + VIP_ENGINE_OPTIONS}
        if engine not in allowed:
            raise ValueError("That deobfuscator is not available.")
        if engine == "15.1" and not member_has_vip_role(interaction.user, interaction.guild.id if interaction.guild else None):
            raise ValueError("Luraph v15.1 is available only to members with the VIP role.")
        result, engine_log = await asyncio.to_thread(run_engine, source, engine)
        deob_failure = find_deobfuscation_failure(result, engine_log)
        if deob_failure:
            raise RuntimeError(deob_failure)
        elapsed = time.monotonic() - start
        description = f"Deobfuscated for {interaction.user.display_name}."
        embed = make_result_embed(
            f"Luraph v{engine} output ready",
            description, result, elapsed,
        )
        attachment = discord.File(fp=io.BytesIO(result.encode("utf-8")), filename="deobfuscated.lua")
        await interaction.followup.send(embed=embed, file=attachment, ephemeral=False,
                                        allowed_mentions=discord.AllowedMentions.none())
    except (ValueError, RuntimeError) as exc:
        await interaction.followup.send(embed=make_failure_embed(str(exc)), ephemeral=False)
    except Exception:
        logging.exception("Deobfuscation button flow failed.")
        await interaction.followup.send(
            embed=make_failure_embed("The request failed unexpectedly. Check the bot's server log."),
            ephemeral=False,
        )


class DeobEngineButton(discord.ui.Button):
    def __init__(self, engine: str, label: str, index: int, recommended: bool):
        super().__init__(
            label=f"{label} · Recommended" if recommended else label,
            style=discord.ButtonStyle.success if recommended else discord.ButtonStyle.secondary,
            row=index // 5,
        )
        self.engine = engine

    async def callback(self, interaction: discord.Interaction) -> None:
        view = self.view
        if not isinstance(view, DeobEngineView):
            return
        if interaction.user.id != view.requester_id:
            await interaction.response.send_message(
                "Only the person who started this `/deob` request can select its engine.", ephemeral=True,
            )
            return
        if not await require_command_access(interaction):
            return
        if self.engine not in dict(view.engine_options):
            await interaction.response.send_message("That engine is not available in this panel.", ephemeral=True)
            return
        if self.engine == "15.1" and not member_has_vip_role(interaction.user, interaction.guild.id if interaction.guild else None):
            await interaction.response.send_message("Luraph v15.1 is VIP-only.", ephemeral=True)
            return
        view.stop()
        await interaction.response.defer(thinking=True, ephemeral=False)
        if interaction.message:
            await interaction.message.edit(
                embed=discord.Embed(
                    title="⏳ Deobfuscation started",
                    description=f"Running **{dict(view.engine_options)[self.engine]}**. The result will be posted here publicly.",
                    color=EMBED_COLOR,
                ),
                view=None,
            )
        await run_selected_deob(interaction, view.source, self.engine)


class DeobEngineView(discord.ui.View):
    def __init__(self, source: str, requester_id: int,
                 engine_options: list[tuple[str, str]], recommended: str | None):
        super().__init__(timeout=300)
        self.source = source
        self.requester_id = requester_id
        self.engine_options = engine_options
        for index, (engine, label) in enumerate(engine_options):
            self.add_item(DeobEngineButton(engine, label, index, engine == recommended))

    async def on_timeout(self) -> None:
        for item in self.children:
            if isinstance(item, discord.ui.Button):
                item.disabled = True
        if hasattr(self, "message") and self.message:
            await self.message.edit(view=self)


class DeobBot(commands.Bot):
    def __init__(self) -> None:
        intents = discord.Intents.default()
        super().__init__(command_prefix=commands.when_mentioned, intents=intents, help_command=None)

    async def setup_hook(self) -> None:
        await self.tree.sync()
        logging.info("Global slash commands synchronized.")


bot = DeobBot()


@bot.event
async def on_ready() -> None:
    logging.info("Logged in as %s; owner ID: %s", bot.user, OWNER_ID)


async def prepare_deob_request(
    interaction: discord.Interaction,
    file: discord.Attachment | None,
    code: str | None,
    engine_options: list[tuple[str, str]],
) -> None:
    await interaction.response.defer(ephemeral=False, thinking=True)
    try:
        if file and code:
            raise ValueError("Upload a file or enter code/a URL, not both.")
        source = await read_input(file, code, allow_plain_text=True)
        label, confidence, _profile = await asyncio.to_thread(detect_obfuscator, source)
        recommended = recommended_engine(label)
        suggested_name = dict(engine_options).get(recommended, "") if recommended else ""
        detail = f"Detected **{label}** ({confidence * 100:.2f}%)."
        if recommended:
            detail += f" **{suggested_name}** is the recommended deobfuscator."
        else:
            detail += " I couldn't identify a clear match, so choose the engine you want to try."
        detail += "\nChoose from the bot's supported engines below. This panel and the result will be visible to everyone."
        embed = discord.Embed(
            title="Choose a deobfuscator",
            description=detail,
            color=EMBED_COLOR,
            timestamp=discord.utils.utcnow(),
        )
        embed.set_author(name="Lua Deobfuscator")
        embed.set_footer(text=f"Requested by {interaction.user.display_name} · selection expires in 5 minutes")
        view = DeobEngineView(source, interaction.user.id, engine_options, recommended)
        view.message = await interaction.followup.send(
            embed=embed, view=view, allowed_mentions=discord.AllowedMentions.none(), ephemeral=False,
        )
    except (ValueError, RuntimeError) as exc:
        await interaction.followup.send(embed=make_failure_embed(str(exc)), ephemeral=False)
    except Exception:
        logging.exception("Could not prepare deobfuscation selection.")
        await interaction.followup.send(
            embed=make_failure_embed("The request failed unexpectedly. Check the bot's server log."),
            ephemeral=False,
        )


@bot.tree.command(name="setup_server", description="OWNER: activate this server for bot use.")
@discord.app_commands.describe(server_id="The ID of this Discord server")
async def setup_server_command(interaction: discord.Interaction, server_id: str) -> None:
    if not await require_owner(interaction):
        return
    try:
        requested_id = int(server_id.strip())
    except ValueError:
        await interaction.response.send_message("Invalid Server ID. Enter numbers only.", ephemeral=True)
        return
    if requested_id != interaction.guild.id:
        await interaction.response.send_message("The entered Server ID must match the server where you run this command.", ephemeral=True)
        return
    settings = config["guilds"].setdefault(str(requested_id), {})
    settings["enabled"] = True
    save_config()
    await interaction.response.send_message(f"Server `{requested_id}` activated. Next, configure its channel with `/setup_channel`.", ephemeral=True)


@bot.tree.command(name="setup_channel", description="OWNER: set the only channel where members can use the bot.")
@discord.app_commands.describe(server_id="The ID of this server", channel_id="The channel ID allowed to use the bot")
async def setup_channel_command(interaction: discord.Interaction, server_id: str, channel_id: str) -> None:
    if not await require_owner(interaction):
        return
    try:
        gid, cid = int(server_id.strip()), int(channel_id.strip())
    except ValueError:
        await interaction.response.send_message("Invalid ID. Server ID and Channel ID must contain numbers only.", ephemeral=True)
        return
    if gid != interaction.guild.id:
        await interaction.response.send_message("The entered Server ID must match the server where you run this command.", ephemeral=True)
        return
    settings = guild_config(gid)
    if not settings.get("enabled"):
        await interaction.response.send_message("Activate this server first with `/setup_server`.", ephemeral=True)
        return
    channel = interaction.guild.get_channel(cid)
    if channel is None or not isinstance(channel, (discord.TextChannel, discord.Thread)):
        await interaction.response.send_message("Channel ID not found in this server or it is not a text channel.", ephemeral=True)
        return
    settings["channel_id"] = cid
    save_config()
    await interaction.response.send_message(f"Bot usage channel set to {channel.mention}.", ephemeral=True)


@bot.tree.command(name="setup_vip_role", description="OWNER: set the VIP role for this server.")
@discord.app_commands.describe(server_id="The ID of this server", role_id="The VIP role ID")
async def setup_vip_role_command(interaction: discord.Interaction, server_id: str, role_id: str) -> None:
    if not await require_owner(interaction):
        return
    try:
        gid, rid = int(server_id.strip()), int(role_id.strip())
    except ValueError:
        await interaction.response.send_message("Invalid ID. Server ID and Role ID must contain numbers only.", ephemeral=True)
        return
    if gid != interaction.guild.id:
        await interaction.response.send_message("The entered Server ID must match the server where you run this command.", ephemeral=True)
        return
    settings = guild_config(gid)
    if not settings.get("enabled"):
        await interaction.response.send_message("Activate this server first with `/setup_server`.", ephemeral=True)
        return
    role = interaction.guild.get_role(rid)
    if role is None:
        await interaction.response.send_message("Role ID not found in this server.", ephemeral=True)
        return
    settings["vip_role_id"] = rid
    save_config()
    await interaction.response.send_message(f"VIP role set to **{role.name}** (`{rid}`).", ephemeral=True)


@bot.tree.command(name="setup_remove_server", description="OWNER: disable bot access in this server.")
@discord.app_commands.describe(server_id="The ID of this Discord server")
async def setup_remove_server_command(interaction: discord.Interaction, server_id: str) -> None:
    if not await require_owner(interaction):
        return
    try:
        gid = int(server_id.strip())
    except ValueError:
        await interaction.response.send_message("Invalid Server ID. Enter numbers only.", ephemeral=True)
        return
    if gid != interaction.guild.id:
        await interaction.response.send_message("The entered Server ID must match the server where you run this command.", ephemeral=True)
        return
    config["guilds"].pop(str(gid), None)
    save_config()
    await interaction.response.send_message(f"Bot access disabled and configuration removed for server `{gid}`.", ephemeral=True)


@bot.tree.command(name="deob", description="Choose a public Luraph deobfuscator for a file, code, or URL.")
@discord.app_commands.describe(file="Lua/Luau source file (up to configured limit)", code="Paste source code or a loadstring URL")
async def deob_command(interaction: discord.Interaction, file: discord.Attachment | None = None, code: str | None = None) -> None:
    if not await require_command_access(interaction):
        return
    await prepare_deob_request(interaction, file, code, PUBLIC_ENGINE_OPTIONS)


@bot.tree.command(name="vipdeob", description="VIP-only Luraph v15.1 deobfuscator.")
@discord.app_commands.describe(file="Lua/Luau source file (up to configured limit)", code="Paste source code or a loadstring URL")
async def vipdeob_command(interaction: discord.Interaction, file: discord.Attachment | None = None, code: str | None = None) -> None:
    if not member_has_vip_role(interaction.user, interaction.guild.id if interaction.guild else None):
        await interaction.response.send_message("`/vipdeob` is available only to members with the server's configured VIP role.", ephemeral=True)
        return
    if not await require_command_access(interaction):
        return
    await prepare_deob_request(interaction, file, code, VIP_ENGINE_OPTIONS)


@bot.tree.command(name="get", description="Fetch code from a public HTTP or HTTPS URL.")
async def get_command(interaction: discord.Interaction, url: str) -> None:
    if not await require_command_access(interaction):
        return
    await interaction.response.defer(ephemeral=False, thinking=True)
    try:
        start = time.monotonic()
        url = url.strip()
        if not is_allowed_fetch_url(url):
            raise ValueError("Enter a direct public HTTP or HTTPS URL (standard ports 80 or 443).")
        source = await asyncio.to_thread(fetch_loader, url)
        elapsed = time.monotonic() - start
        embed = await asyncio.to_thread(make_get_embed, source, url, elapsed)
        attachment = discord.File(fp=io.BytesIO(source.encode("utf-8")), filename="fetched.lua")
        await interaction.followup.send(embed=embed, file=attachment, allowed_mentions=discord.AllowedMentions.none(), ephemeral=False)
    except (ValueError, RuntimeError) as exc:
        await interaction.followup.send(f"Couldn't fetch this source: {exc}", ephemeral=False)
    except Exception:
        logging.exception("/get failed.")
        await interaction.followup.send("The fetch failed unexpectedly. Check the bot's server log.", ephemeral=False)


@bot.tree.command(name="detect", description="Detect the obfuscator in a file, pasted code, or URL.")
@discord.app_commands.describe(file="Lua/Luau source file (up to configured limit)", code="Paste source code or a URL")
async def detect_command(interaction: discord.Interaction, file: discord.Attachment | None = None, code: str | None = None) -> None:
    if not await require_command_access(interaction):
        return
    await interaction.response.defer(ephemeral=False, thinking=True)
    try:
        if file and code:
            raise ValueError("Upload a file or enter code/a URL, not both.")
        source = await read_input(file, code, allow_plain_text=True)
        embed = await asyncio.to_thread(make_detect_embed, source)
        await interaction.followup.send(embed=embed, allowed_mentions=discord.AllowedMentions.none(), ephemeral=False)
    except (ValueError, RuntimeError) as exc:
        await interaction.followup.send(f"Couldn't detect this input: {exc}", ephemeral=False)
    except Exception:
        logging.exception("/detect failed.")
        await interaction.followup.send("Detection failed unexpectedly. Check the bot's server log.", ephemeral=False)


@bot.tree.command(name="supported", description="List the Luraph versions available in this bot.")
async def supported_command(interaction: discord.Interaction) -> None:
    if not await require_command_access(interaction):
        return
    embed = discord.Embed(
        title="🧰 Supported Luraph versions",
        description="The bot's deobfuscation engines are limited to the Luraph versions below.",
        color=EMBED_COLOR,
        timestamp=discord.utils.utcnow(),
    )
    embed.add_field(name="Public", value="**v14.7** · **v14.8** · **v14.9** · **v15**", inline=False)
    embed.add_field(name="VIP only", value="**v15.1** · use `/vipdeob` (role required)", inline=False)
    embed.add_field(name="Input", value=f"Lua/Luau file, pasted source, or a loader URL. Maximum input size: {MAX_SOURCE_MB} MB.", inline=False)
    embed.add_field(name="Linux host requirement", value="The host needs `bin/luau` and `bin/luau-ast`. Start with `host_start.py` to build them if the host provides git, CMake, g++, and network access.", inline=False)
    embed.set_author(name="Lua Deobfuscator")
    embed.set_footer(text="Commands are available in the configured bot channel.")
    await interaction.response.send_message(embed=embed, allowed_mentions=discord.AllowedMentions.none(), ephemeral=False)


@bot.tree.command(name="help", description="Show the bot commands and what each one does.")
async def help_command(interaction: discord.Interaction) -> None:
    if not await require_command_access(interaction):
        return
    embed = discord.Embed(
        title="📖 Bot command guide",
        description="Use these commands in the server's configured channel (or a thread inside it). Setup commands are OWNER-only.",
        color=EMBED_COLOR,
        timestamp=discord.utils.utcnow(),
    )
    embed.add_field(
        name="`/deob` · Deobfuscate",
        value="Process a Lua/Luau file, paste code directly, or fetch a source URL/loadstring. Choose public Luraph v14.7, v14.8, v14.9, or v15. Results are public with a preview and `.lua` file.",
        inline=False,
    )
    embed.add_field(
        name="`/vipdeob` · VIP deobfuscator",
        value="Run the Luraph v15.1 engine. Requires the server's configured VIP role.",
        inline=False,
    )
    embed.add_field(
        name="`/get <url>` · Fetch source",
        value="Download source from a public HTTP/HTTPS URL and show a preview plus the fetched file.",
        inline=False,
    )
    embed.add_field(
        name="`/detect` · Identify format",
        value="Inspect a file or pasted code/URL and report whether it appears to be Luraph, its version, and confidence. Other obfuscators are reported as unsupported.",
        inline=False,
    )
    embed.add_field(
        name="`/supported` · List engines",
        value="Show supported Luraph versions and host requirements.",
        inline=False,
    )
    embed.add_field(
        name="`/help` · This guide",
        value="Show this command list.",
        inline=False,
    )
    embed.add_field(
        name="OWNER setup commands",
        value="`/setup_server` · activate server; `/setup_channel` · choose allowed channel; `/setup_vip_role` · set VIP role; `/setup_remove_server` · revoke access. All require the OWNER account.",
        inline=False,
    )
    embed.set_footer(text="Server activation, channel selection, and VIP role configuration are controlled by the bot owner.")
    await interaction.response.send_message(embed=embed, allowed_mentions=discord.AllowedMentions.none(), ephemeral=False)


@bot.event
async def on_command_error(ctx: commands.Context, error: commands.CommandError) -> None:
    if isinstance(error, commands.CommandNotFound):
        return
    if isinstance(error, commands.MissingRequiredArgument):
        await ctx.send("Missing input. Use /help to see command formats.")
        return
    logging.error("Prefix command failed: %s", error,
                  exc_info=(type(error), error, error.__traceback__))
    await ctx.send("That command failed. Check the bot's server log.")


token = os.environ.get("DISCORD_TOKEN")
if not token:
    raise SystemExit("Set DISCORD_TOKEN in the environment before starting the bot.")
bot.run(token)
