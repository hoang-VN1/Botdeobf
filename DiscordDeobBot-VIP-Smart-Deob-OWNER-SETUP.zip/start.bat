@echo off
setlocal
cd /d "%~dp0"
if not exist .env (
  copy .env.example .env >nul
  echo Add your Discord bot token on the DISCORD_TOKEN= line, save, then close Notepad.
  start "" /wait notepad.exe .env
)
if not exist .venv\Scripts\python.exe call setup.bat
if not exist .venv\Scripts\python.exe exit /b 1
.venv\Scripts\python.exe -c "import discord, dotenv" >nul 2>nul
if errorlevel 1 .venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto failed
.venv\Scripts\python.exe bot.py
if errorlevel 1 pause
exit /b
:failed
echo Could not install packages. Check internet access and retry.
pause
exit /b 1

